
import { GoogleGenAI, Type } from "@google/genai";
import { FriendshipMessage } from "../types";

export const generateFriendshipMessage = async (): Promise<FriendshipMessage> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: "Write a super cute, warm, and heartfelt 'Certificate of Best Friendship' message. Include a cute title, a short sweet paragraph about being 'one call away', and 3 funny/sweet reasons why we are the best friends ever.",
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          message: { type: Type.STRING },
          reasons: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["title", "message", "reasons"]
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    return {
      title: "Official Besties!",
      message: "I'm always just one call away, ready to listen, laugh, and be there for you whenever you need me.",
      reasons: [
        "You have the best snacks",
        "We share the same brain cell",
        "You always know how to make me smile"
      ]
    };
  }
};
