
import React, { useEffect, useState } from 'react';

// Added React.FC type to ensure the component accepts standard React props like 'key' when used in TSX lists
const Heart: React.FC<{ left: number; delay: number; size: number }> = ({ left, delay, size }) => (
  <div 
    className="absolute text-pink-300 pointer-events-none animate-bounce opacity-20"
    style={{
      left: `${left}%`,
      bottom: '-50px',
      fontSize: `${size}px`,
      animationDelay: `${delay}s`,
      animationDuration: `${3 + Math.random() * 4}s`,
      transform: `translateY(-100vh)`
    }}
  >
    ❤️
  </div>
);

export const FloatingHearts: React.FC = () => {
  const [hearts, setHearts] = useState<Array<{ id: number; left: number; delay: number; size: number }>>([]);

  useEffect(() => {
    const newHearts = Array.from({ length: 15 }).map((_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 5,
      size: 10 + Math.random() * 30
    }));
    setHearts(newHearts);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {hearts.map(h => (
        <Heart key={h.id} left={h.left} delay={h.delay} size={h.size} />
      ))}
    </div>
  );
};
